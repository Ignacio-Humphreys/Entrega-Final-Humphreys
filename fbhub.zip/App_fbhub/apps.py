from django.apps import AppConfig


class AppFbhubConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'App_fbhub'
